from flask import Flask, request, escape
from flask_cors import CORS
from marvel import Marvel
import functions_framework

# define um app flask interno
app = Flask('internal')
cors = CORS(app)

PUBLIC_KEY = 'b85e6a9dd0ffe5c148cd0f479999788a'
PRIVATE_KEY = '3d5d3b0475cfcb1661fff79f53ba522278a5d633'

# instancia api marvel    
marvel = Marvel(PUBLIC_KEY, PRIVATE_KEY)

# Define the internal path, idiomatic Flask definition
@app.route('/', methods=['GET', 'POST'])
def home():
    # obtem os personagens
    characters = marvel.characters 
    
    # inicia a lista de resposta
    response = []
  
    # serial code of your favourite character
    characters_code  = 1011334 
    
    # this can be different according to your preference    
    for n in range (0, 6):     
        # serach for comics of this character
        all_characters=characters.comics(characters_code)       
        characters_code = characters_code+1 
        for i in range (1,12):
            data = all_characters['data']['results'][int(i)]['title']
            response.append(data)
            # print(data)
    
    return escape(response), 200

# personagen
@app.route('/characters/', methods=['GET', 'POST'])
def characters():
    print('/characters')
    kwargs = get_params(request.args)  
        
    if 'etag' in kwargs:
        kwargs['headers'] = { 'If-None-Match': kwargs['etag']  }
        del kwargs['etag']
    
    characters = marvel.characters.all(**kwargs)
    
    return characters, 200

# personagen
@app.route('/characters/<int:id>', methods=['GET', 'POST'])
def characters_id(id):
    kwargs = get_params(request.args)
    character = marvel.characters.get(id, **kwargs)
    print(character)
    return character, 200

# get comics by characters
@app.route('/comics_by_character/<int:id>', methods=['GET'])
def get_comics_by_character(id):
    comics = marvel.comics.all(characters=str(id))
    return comics, 200

# comics
@app.route('/comics', methods=['GET', 'POST'])
def comics():
    print('/comics')  
    kwargs = get_params(request.args)      
    comics = marvel.comics.all(**kwargs)
    print('end/comics')
    return comics, 200

def get_params(request_args):
    kwargs = {}
    if request_args:        
        for arg in request_args:
            kwargs[arg]=request_args[arg]
    return kwargs           


# funcão de entrada
@functions_framework.http
def hello_http(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    """
   
    #Create a new app context for the internal app
    internal_ctx = app.test_request_context(path=request.full_path,
                                            method=request.method)
    
    #Copy main request data from original request
    #According to your context, parts can be missing. Adapt here!
    internal_ctx.request.data = request.data
    print('request', request.headers)
    internal_ctx.request.headers = request.headers
    
    #Activate the context
    internal_ctx.push()
    #Dispatch the request to the internal app and get the result 
    return_value = app.full_dispatch_request()
    #Offload the context
    internal_ctx.pop()
    
    #Return the result of the internal app routing and processing      
    return return_value